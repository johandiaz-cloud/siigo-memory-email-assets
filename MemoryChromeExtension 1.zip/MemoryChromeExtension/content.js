var data = [];

// para detectar donde estoy parado y poder automatizar mas la carga de datos
//Y darle a BO mas datos sobre la empresa 

// for (var i = 0; i < document.forms.length; i++) {
//     document.forms[i].addEventListener("submit", function(){

//         let url = window.location.href;
//         inputs = document.getElementsByTagName('input');
//         for (index = 0; index < inputs.length; ++index) {
//             if (inputs[index].type != "hidden")  {  
//                 var element = {};
//                 element.id = inputs[index].id;
//                 element.name = inputs[index].name;
//                 element.type = inputs[index].type;
//                 element.value = inputs[index].value;
//                 element.url = url.substring(1,40);
//                 data.push(element); 
//             }
//         }         
//     });
// }