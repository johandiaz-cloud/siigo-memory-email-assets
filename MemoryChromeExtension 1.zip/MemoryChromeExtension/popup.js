var gData;

document.addEventListener('DOMContentLoaded', async () => {
    console.log('Memory BO Extension 1.0');
})

//Obtengo los datos de BO y lo guardo en una variable global para que luego lo populen
document.getElementById('btnSearch').addEventListener("click", function(){    
   
    var sRut = document.getElementById("search").value;
    const data = new FormData();
    data.append('rut', sRut);
    data.append('key', '56623EB7-0349-4447-8C1A-9B3C5C9818D5');

    fetch('https://memorybackoffice.azurewebsites.net/Empresa/GetEmpresaData', {
        method: 'POST',
        body: data
     })
     .then(function(response) {
        if(response.ok) {
            return response;
        } else {
            throw "Error en la llamada Ajax";
        }     
     })
     .then(function(response) {
        // Examine the text in the response
        response.json().then(function(data) {                                
            SetDataHtml(data);
            gData = data;
        });
     })
     .catch(function(err) {
        console.log(err);
     });
});


function SetDataHtml(data){
    document.getElementById('dRut').textContent = data.Rut;
    document.getElementById('dCI').textContent = data.UsuarioEFacturaDGICedula;
    document.getElementById('dDocResp').textContent = data.DocumentoResponsable;
    document.getElementById('dSerLineaRut').textContent = data.ServicioLineaRUT;                        
    document.getElementById('dSerLineaPass').textContent = data.ServicioLineaPass;
    document.getElementById('deFacturaCI').textContent = data.eFacturaCedula;
    document.getElementById('deFacturaPass').textContent = data.eFacturaPass;
    document.getElementById('dEmailInter').textContent = data.EmpresaEmailIntercambio;                        
    document.getElementById('dRazonS').textContent = data.RazonSocial;
    document.getElementById('dNombreCom').textContent = data.NombreComercial;                        
    document.getElementById('dDepar').textContent = data.Departamento;
    document.getElementById('dLocalidad').textContent = data.Localidad;                        
    document.getElementById('dDirec').textContent = data.Direccion;
    document.getElementById('dCodPostal').textContent = data.CodigoPostal;                        
    document.getElementById('dNroLocal').textContent = data.EmpresaNrLocal;
    document.getElementById('dDGIEmail').textContent = data.DGIEmail;                        
    document.getElementById('dDGITel').textContent = data.DGITelefono;
    document.getElementById('dPNombre').textContent = data.NombrePrimer;                        
    document.getElementById('dSNombre').textContent = data.NombreSegundo;                        
    document.getElementById('dPApell').textContent = data.ApellidoPrimer;                        
    document.getElementById('dSApell').textContent = data.ApellidoSegundo;          
}

//con esto puedo obtener los componentes de una pagina con json
document.getElementById('btnGetHtml').addEventListener("click", function(){
    console.log('btnGetHtml');

    chrome.tabs.query({active: true}, function(tabs) {
        var tab = tabs[0];
        chrome.tabs.executeScript(
                tab.id, {
                file: 'inject.js'                
            }, null);            
    });
});

//Copio lo que obtuve al formulario de la pagina
document.getElementById('btnPopularAbitab').addEventListener("click", function(){
    
    var emailLiteralE = "literale@memory.com.uy";

    chrome.tabs.query({active: true}, function(tabs) {
        var tab = tabs[0];

        chrome.tabs.executeScript(
            tab.id, {
            code: `if (document.getElementById('text_2') != null) document.getElementById('text_2').value = "${gData.DocumentoResponsable}";
                    if (document.getElementById('text_14') != null) document.getElementById('text_14').value = "${gData.Rut}";
                    if (document.getElementById('text_3') != null) document.getElementById('text_3').value = "${gData.NombrePrimer}";
                    if (document.getElementById('text_4') != null) document.getElementById('text_4').value = "${gData.NombreSegundo}";
                    if (document.getElementById('text_5') != null) document.getElementById('text_5').value = "${gData.ApellidoPrimer}";
                    if (document.getElementById('text_6') != null) document.getElementById('text_6').value = "${gData.ApellidoSegundo}";
                    if (document.getElementById('text_7') != null) document.getElementById('text_7').value = "${gData.RazonSocial}";
                    if (document.getElementById('text_9') != null) document.getElementById('text_9').value = "${gData.NombreComercial}";

                    if (document.getElementById('email_10') != null) document.getElementById('email_10').value = "${emailLiteralE}";
                    if (document.getElementById('email-confirm_10') != null) document.getElementById('email-confirm_10').value = "${emailLiteralE}";

                    if (document.getElementById('email_11') != null) document.getElementById('email_11').value = "${gData.DGIEmail}";
                    if (document.getElementById('email-confirm_11') != null) document.getElementById('email-confirm_11').value = "${gData.DGIEmail}";       
                    if (document.getElementById('text_12') != null) document.getElementById('text_12').value = "${gData.DGITelefono}";     
		    if (document.getElementById('text_13') != null) document.getElementById('text_13').value = "${gData.DGITelefono}";`                       
                                              
        }, null);
    });
});


document.getElementById('btnPopularDGIServiciosEnLineaLogin').addEventListener("click", function(){
    
    chrome.tabs.query({active: true}, function(tabs) {
        var tab = tabs[0];

        chrome.tabs.executeScript(
            tab.id, {
            code: `if (document.getElementById('logFld_885_73_2_1') != null) document.getElementById('logFld_885_73_2_1').value = "${gData.ServicioLineaRUT}";
                   if (document.getElementById('logFld_885_73_2_2') != null) document.getElementById('logFld_885_73_2_2').value = "${gData.ServicioLineaPass}";`               
        }, null);
    });
});

document.getElementById('btnPopularDGIeFactura').addEventListener("click", function(){
    
    chrome.tabs.query({active: true}, function(tabs) {
        var tab = tabs[0];

        chrome.tabs.executeScript(
            tab.id, {
            code: `if (document.getElementById('W0023W000900010001W0003W0003vUSER') != null) document.getElementById('W0023W000900010001W0003W0003vUSER').value = "${gData.ServicioLineaRUT}";
                    if (document.getElementById('W0023W000900010001W0003W0003vUSER2') != null) document.getElementById('W0023W000900010001W0003W0003vUSER2').value = "${gData.eFacturaCedula}";
                   if (document.getElementById('W0023W000900010001W0003W0003vPASSWORD') != null) document.getElementById('W0023W000900010001W0003W0003vPASSWORD').value = "${gData.eFacturaPass}";`               
        }, null);
    });
});


