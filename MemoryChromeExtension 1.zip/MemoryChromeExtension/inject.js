(function(){
    console.log('Hecho Memory BO.0');
    var data = '[';
    var labelss = document.getElementsByTagName("input"); 
    for (var i=0; i < labelss.length; i++){
        data += '{\"id\":\"' + labelss[i].id + '\",'+ 
              '\"name\":\"'+labelss[i].text+'\",'+
              '\"type\":\"'+labelss[i].type+'\",'+
              '\"elem\":\"'+'input'+'\",'+
              '\"value\":\"'+labelss[i].value+'\"}';

        data += ','
    }

    data += ']';
    data = data.replace('},]','}]');
    console.log(data);
    var input = document.createElement('TEXTAREA');
    input.setAttribute('id', 'TextAreaMemoryData');
    document.getElementsByTagName("body")[0].appendChild(input);

    var myTextArea = document.getElementById('TextAreaMemoryData');
    myTextArea.value = data;
    console.log('Hecho Memory BO.3');
})();